<?php
error_reporting(0);
session_start();

if (isset($_POST['search'])) {
  // Fetch the username from the form
  $username = $_POST['username'];

  // Get details from API
  $request = [
    'username' => $username
  ];

  $curl = curl_init();

  curl_setopt_array($curl, [
    CURLOPT_URL => "https://twitter154.p.rapidapi.com/user/details",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => json_encode($request),
    CURLOPT_HTTPHEADER => [
      "X-RapidAPI-Host: twitter154.p.rapidapi.com",
      "X-RapidAPI-Key: 760ca66ae6mshdd8003e530d7a6fp159d83jsn132b74adfa5d",
      "content-type: application/json"
    ],
  ]);

  $response = curl_exec($curl);
  $err = curl_error($curl);

  curl_close($curl);

  $res = json_decode($response);

  if ($err) {
    $_SESSION['danger'] = "cURL Error #:" . $err;
  	echo "<script>window.location.assign('./')</script>";
  }
  elseif ($res->detail) {
    $_SESSION['warning'] = $res->detail;
  	echo "<script>window.location.assign('./')</script>";
  }
  elseif ($res->message) {
    $_SESSION['warning'] = $res->message;
  	echo "<script>window.location.assign('./')</script>";
  }
  else {
    // $_SESSION['success'] = 'Retriving Details';
    $_SESSION['username'] = $res->username;
    $_SESSION['user_id'] = $res->user_id;
  	echo "<script>window.location.assign('result')</script>";
    echo "<pre>";
    echo $response;
    echo "</pre>";
  }

}
else{
	$_SESSION['warning'] = 'No shortcuts, Fill up form first';
	echo "<script>window.location.assign('./')</script>";
}


 ?>
